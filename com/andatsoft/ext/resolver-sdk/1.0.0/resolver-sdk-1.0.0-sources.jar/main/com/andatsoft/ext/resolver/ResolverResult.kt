package com.andatsoft.ext.resolver

import android.os.Bundle

/**
 * Parses and builds V1 resolve result [Bundle] payloads.
 */
object ResolverResult {

    /**
     * Builds a successful resolve result bundle.
     *
     * @param videoUrl Direct playable stream URL.
     * @param streamType Optional stream hint (for example [ResolverContract.STREAM_TYPE_HLS]).
     * @param headers Optional HTTP request headers for playback.
     * @param subtitleUrl Optional external subtitle URL.
     * @return Result bundle for IPC.
     */
    fun success(
        videoUrl: String,
        streamType: String? = null,
        headers: Bundle? = null,
        subtitleUrl: String? = null,
    ): Bundle = Bundle().apply {
        putBoolean(ResolverContract.KEY_SUCCESS, true)
        putString(ResolverContract.KEY_VIDEO_URL, videoUrl)
        if (!streamType.isNullOrBlank()) {
            putString(ResolverContract.KEY_STREAM_TYPE, streamType)
        }
        if (headers != null && !headers.isEmpty) {
            putBundle(ResolverContract.KEY_HEADERS, headers)
        }
        if (!subtitleUrl.isNullOrBlank()) {
            putString(ResolverContract.KEY_SUBTITLE_URL, subtitleUrl)
        }
    }

    /**
     * Builds a failed resolve result bundle.
     *
     * @param error Human-readable error message.
     * @return Result bundle for IPC.
     */
    fun failure(error: String): Bundle = Bundle().apply {
        putBoolean(ResolverContract.KEY_SUCCESS, false)
        putString(ResolverContract.KEY_ERROR, error)
    }

    /**
     * Returns whether the result bundle indicates success.
     *
     * @param result Result bundle from a plugin.
     * @return True when [ResolverContract.KEY_SUCCESS] is true.
     */
    fun isSuccess(result: Bundle?): Boolean = result?.getBoolean(ResolverContract.KEY_SUCCESS) == true

    /**
     * Reads the playable video URL from a result bundle.
     *
     * @param result Result bundle from a plugin.
     * @return Stream URL, or null when missing or blank.
     */
    fun getVideoUrl(result: Bundle?): String? {
        return result?.getString(ResolverContract.KEY_VIDEO_URL)?.trim()?.takeIf { it.isNotEmpty() }
    }

    /**
     * Reads the optional stream type hint from a result bundle.
     *
     * @param result Result bundle from a plugin.
     * @return Stream type string, or null when absent.
     */
    fun getStreamType(result: Bundle?): String? {
        return result?.getString(ResolverContract.KEY_STREAM_TYPE)?.trim()?.takeIf { it.isNotEmpty() }
    }

    /**
     * Reads optional HTTP headers from a result bundle.
     *
     * @param result Result bundle from a plugin.
     * @return Header map, or empty map when absent.
     */
    fun getHeaders(result: Bundle?): Map<String, String> {
        val headersBundle = result?.getBundle(ResolverContract.KEY_HEADERS) ?: return emptyMap()
        val map = linkedMapOf<String, String>()
        for (key in headersBundle.keySet()) {
            val value = headersBundle.getString(key)
            if (!key.isNullOrBlank() && !value.isNullOrBlank()) {
                map[key] = value
            }
        }
        return map
    }

    /**
     * Reads the optional subtitle URL from a result bundle.
     *
     * @param result Result bundle from a plugin.
     * @return Subtitle URL, or null when absent.
     */
    fun getSubtitleUrl(result: Bundle?): String? {
        return result?.getString(ResolverContract.KEY_SUBTITLE_URL)?.trim()?.takeIf { it.isNotEmpty() }
    }

    /**
     * Reads the error message from a result bundle.
     *
     * @param result Result bundle from a plugin.
     * @return Error message, or null when absent.
     */
    fun getError(result: Bundle?): String? {
        return result?.getString(ResolverContract.KEY_ERROR)?.trim()?.takeIf { it.isNotEmpty() }
    }
}
