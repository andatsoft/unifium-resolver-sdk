package com.andatsoft.ext.resolver

import android.os.Bundle

/**
 * Builds V1 resolve request [Bundle] payloads for [IVideoResolverService.resolveAsync].
 */
object ResolverRequest {

    /**
     * Creates a V1 resolve request bundle.
     *
     * @param url Page or stream URL to resolve.
     * @param apiVersion Contract API version; defaults to [ResolverContract.API_VERSION].
     * @param timeoutMs Maximum resolve duration in milliseconds.
     * @return Request bundle for IPC.
     */
    fun build(
        url: String,
        apiVersion: Int = ResolverContract.API_VERSION,
        timeoutMs: Long = ResolverContract.DEFAULT_TIMEOUT_MS,
    ): Bundle = Bundle().apply {
        putString(ResolverContract.KEY_URL, url)
        putInt(ResolverContract.KEY_API_VERSION, apiVersion)
        putLong(ResolverContract.KEY_TIMEOUT, timeoutMs)
    }

    /**
     * Reads the input URL from a resolve request bundle.
     *
     * @param request Request bundle from the host app.
     * @return URL string, or null when missing or blank.
     */
    fun getUrl(request: Bundle?): String? {
        return request?.getString(ResolverContract.KEY_URL)?.trim()?.takeIf { it.isNotEmpty() }
    }

    /**
     * Reads the requested API version from a resolve request bundle.
     *
     * @param request Request bundle from the host app.
     * @return API version, or [ResolverContract.API_VERSION] when absent.
     */
    fun getApiVersion(request: Bundle?): Int {
        return request?.getInt(ResolverContract.KEY_API_VERSION, ResolverContract.API_VERSION)
            ?: ResolverContract.API_VERSION
    }

    /**
     * Reads the resolve timeout from a request bundle.
     *
     * @param request Request bundle from the host app.
     * @return Timeout in milliseconds, or [ResolverContract.DEFAULT_TIMEOUT_MS] when absent.
     */
    fun getTimeoutMs(request: Bundle?): Long {
        if (request == null || !request.containsKey(ResolverContract.KEY_TIMEOUT)) {
            return ResolverContract.DEFAULT_TIMEOUT_MS
        }
        return request.getLong(ResolverContract.KEY_TIMEOUT, ResolverContract.DEFAULT_TIMEOUT_MS)
    }
}
