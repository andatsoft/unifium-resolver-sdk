package com.andatsoft.ext.resolver

/**
 * Shared constants for the video resolver plugin IPC contract (V1).
 */
object ResolverContract {

    /** Intent action used to discover resolver plugin services. */
    const val ACTION_RESOLVE_VIDEO = "com.andatsoft.ext.intent.RESOLVE_VIDEO"

    /** Current resolver API version. */
    const val API_VERSION = 1

    /** Default resolve timeout in milliseconds when the host does not override it. */
    const val DEFAULT_TIMEOUT_MS = 30_000L

    // --- Match scores ---

    const val MATCH_UNSUPPORTED = 0
    const val MATCH_GENERIC = 1
    const val MATCH_PROBABLE = 50
    const val MATCH_EXACT = 100

    // --- Request bundle keys ---

    const val KEY_URL = "url"
    const val KEY_API_VERSION = "api_version"
    const val KEY_TIMEOUT = "timeout"

    // --- Result bundle keys ---

    const val KEY_SUCCESS = "success"
    const val KEY_VIDEO_URL = "video_url"
    const val KEY_STREAM_TYPE = "stream_type"
    const val KEY_HEADERS = "headers"
    const val KEY_SUBTITLE_URL = "subtitle_url"
    const val KEY_ERROR = "error"

    // --- Stream type hints (optional metadata for hosts) ---

    const val STREAM_TYPE_HLS = "hls"
    const val STREAM_TYPE_DASH = "dash"
    const val STREAM_TYPE_MP4 = "mp4"
    const val STREAM_TYPE_OTHER = "other"
}
