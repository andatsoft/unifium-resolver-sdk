package com.andatsoft.ext.resolver

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.IBinder
import android.os.RemoteException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Optional base class for resolver plugin services.
 *
 * Runs extraction on [Dispatchers.IO] and never blocks the Binder thread.
 */
abstract class BaseVideoResolverService : Service() {

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(serviceJob + Dispatchers.Main.immediate)

    private val binder = object : IVideoResolverService.Stub() {

        override fun getApiVersion(): Int = ResolverContract.API_VERSION

        override fun getResolverName(): String = provideResolverName()

        override fun match(url: String?): Int {
            if (url.isNullOrBlank()) {
                return ResolverContract.MATCH_UNSUPPORTED
            }
            return computeMatchScore(url)
        }

        override fun resolveAsync(request: Bundle?, callback: IResolveCallback?) {
            if (callback == null) {
                return
            }
            val pageUrl = ResolverRequest.getUrl(request)
            if (pageUrl == null) {
                dispatchError(callback, "Missing or invalid url")
                return
            }
            serviceScope.launch {
                try {
                    val result = withContext(Dispatchers.IO) {
                        resolvePageUrl(pageUrl, request ?: Bundle.EMPTY)
                    }
                    dispatchSuccess(callback, result)
                } catch (e: Exception) {
                    dispatchError(callback, e.message ?: "Resolve failed")
                }
            }
        }
    }

    /**
     * Human-readable resolver name shown in the host app picker.
     */
    protected abstract fun provideResolverName(): String

    /**
     * Returns a support score for the given page URL.
     *
     * @param url Input page URL.
     * @return One of [ResolverContract.MATCH_UNSUPPORTED], [ResolverContract.MATCH_GENERIC],
     *   [ResolverContract.MATCH_PROBABLE], or [ResolverContract.MATCH_EXACT].
     */
    protected abstract fun computeMatchScore(url: String): Int

    /**
     * Extracts a playable stream URL from the page URL on a background thread.
     *
     * @param pageUrl Input page URL.
     * @param request Full V1 request bundle.
     * @return Success or failure result bundle.
     */
    protected abstract suspend fun resolvePageUrl(pageUrl: String, request: Bundle): Bundle

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        serviceScope.cancel()
        serviceJob.cancel()
        super.onDestroy()
    }

    private fun dispatchSuccess(callback: IResolveCallback, result: Bundle) {
        try {
            callback.onSuccess(result)
        } catch (_: RemoteException) {
            // Host disconnected.
        }
    }

    private fun dispatchError(callback: IResolveCallback, error: String) {
        try {
            callback.onError(error)
        } catch (_: RemoteException) {
            // Host disconnected.
        }
    }
}
